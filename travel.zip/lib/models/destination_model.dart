

class SliderShow {
  String imageUrl;
  String title;
  String description;
  String capon;

  SliderShow({
    required this.imageUrl,
    required this.title,
    required this.description,
    required this.capon,
  });
}

List<SliderShow> sliderShow = [
  SliderShow(
    imageUrl: 'assets/images/1.jfif',
    title: 'كاش باك',
    description: 'استخدم الكود وخذلك كاش باك على كل طلب',
    capon: 'SUJ45Y',
  ),
  SliderShow(
    imageUrl: 'assets/images/2.png',
    title: 'كاش باك',
    description: 'استخدم الكود وخذلك كاش باك على كل طلب',
    capon: 'SUJ45Y',
  ),
  SliderShow(
    imageUrl: 'assets/images/3.jfif',
    title: 'كاش باك',
    description: 'استخدم الكود وخذلك كاش باك على كل طلب',
    capon: 'SUJ45Y',
  ),
  SliderShow(
    imageUrl: 'assets/images/venice.jpg',
    title: 'كاش باك',
    description: 'استخدم الكود وخذلك كاش باك على كل طلب',
    capon: 'SUJ45Y',
  ),
  SliderShow(
    imageUrl: 'assets/images/venice.jpg',
    title: 'كاش باك',
    description: 'استخدم الكود وخذلك كاش باك على كل طلب',
    capon: 'SUJ45Y',
  ),
];
