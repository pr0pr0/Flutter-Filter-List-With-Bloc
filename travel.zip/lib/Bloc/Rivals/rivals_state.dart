part of 'rivals_bloc.dart';

abstract class RivalsState extends Equatable {
  const RivalsState();
  
  @override
  List<Object> get props => [];
}

class RivalsInitial extends RivalsState {}
