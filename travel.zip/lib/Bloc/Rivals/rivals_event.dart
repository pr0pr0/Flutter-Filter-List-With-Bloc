part of 'rivals_bloc.dart';

abstract class RivalsEvent extends Equatable {
  const RivalsEvent();

  @override
  List<Object> get props => [];
}
